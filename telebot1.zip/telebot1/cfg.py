TOKEN = "6193373238:AAFxcz_FVmM4N9eDISe-5w2k11R2W5iZ0XY"

keys = {
    'доллар': 'USD',
    'евро': 'EUR',
    'рубль': 'RUR',
}