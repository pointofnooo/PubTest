import pytest

from app.calculator import Calculator

class TestCalcSuccess:
    def setup(self):
        self.calculator = Calculator

    def test_adding_success(self):
        assert self.calculator.adding(self, 1, 1) == 2

    def test_nulification_divison(self):
        with pytest.raises(ZeroDivisionError):
            self.calculator.division(self, 1, 0)

    def teardown(self):
        print('Выполнение метода Teardown')

    def test_division_calculation_correct(self):
        assert self.calculator.division(self, 3, 3) == 1

    def test_subtraction_calculate_correct(self):
        assert self.calculator.subtraction(self, 10, 5) == 5

    def test_adding_calculate_correct(self):
        assert self.calculator.adding(self, 5, 5) == 10


class TestCalcFail:

    def test_adding_failure(self):
        assert self.calculator.adding(self, 1, 1) == 3

    def test_division_calculation_failure(self):
        assert self.calculator.division(self, 3, 2) == 1

    def test_subtraction_calculation_failure(self):
        assert self.calculator.subtraction(self, 10, 11) == 2

    def test_adding_calculation_failure(self):
        assert self.calculator.adding(self, 5, 10) == 10